package com.mastering.spring.cloud.data.flow;
public enum StockTicker {
	GOOGLE, FACEBOOK, TWITTER, IBM, MICROSOFT
}
