package com.mastering.spring.kotlin.firstwebservicewithkotlin.bean

data class WelcomeBean(val message: String = "")