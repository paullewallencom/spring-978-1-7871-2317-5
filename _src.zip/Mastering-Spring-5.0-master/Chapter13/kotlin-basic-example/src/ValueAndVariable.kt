class ValueAndVariable {
}

fun main(args: Array<String>) {
	val constantValue = 1
	var i = 5;
	i++;
	//constantValue++; COMPILER ERROR Val cannot be reassigned
}